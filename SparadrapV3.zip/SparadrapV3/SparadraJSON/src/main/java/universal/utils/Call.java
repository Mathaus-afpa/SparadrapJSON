package universal.utils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.lang3.tuple.Pair;

import java.text.SimpleDateFormat;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * [Call] - class
 * @author Mathaus
 */
public class Call {
	//<editor-fold defaultstate="expanded" desc="STATIC">
	//START________________________________________________[static]___________________________________________________//
	//<editor-fold defaultstate="expanded" desc="PUBLIC">
    //<editor-fold defaultstate="expanded" desc="Proprietes PUBLIC">
    //</editor-fold>
	//<editor-fold defaultstate="expanded" desc="Fonctions PUBLIC">
	public final static String dateToString(java.util.Date date) {
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
		return sdf.format(date);
	}
	public final static Pair<String, String> calcChecksums(String strValue) {
		String md5Checksum = org.apache.commons.codec.digest.DigestUtils.md5Hex(strValue);
		String sha1Checksum = org.apache.commons.codec.digest.DigestUtils.sha1Hex(strValue);
		return Pair.of(md5Checksum, sha1Checksum);
	}
    //</editor-fold>
	//</editor-fold>
	//<editor-fold defaultstate="expanded" desc="PRIVATE">
    //<editor-fold defaultstate="expanded" desc="Proprietes PRIVATE">
    //</editor-fold>
    //<editor-fold defaultstate="expanded" desc="Fonctions PRIVATE">
    //</editor-fold>
	//</editor-fold>
    //END//////////////////////////////////////////////////[static]/////////////////////////////////////////////////////
	//</editor-fold>
    //START_______________________________________________[instance]__________________________________________________//
	private Call() {}
    //END/////////////////////////////////////////////////[instance]////////////////////////////////////////////////////
}