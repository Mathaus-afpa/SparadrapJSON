package data.sparadrap;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.lang3.tuple.Pair;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;

import static universal.utils.Call.calcChecksums;
import static universal.utils.Call.dateToString;

public final class UniversalJSON
{
    private boolean useChecksum = true;
    private boolean stringOnly = false;
    private Map<String, Object> values = new HashMap<>();
    private Map<String, DataTypes> datatypes = new HashMap<>();
    private Map<String, Pair<String, String>> checksums = new HashMap<>();
    private String md5Checksum = null;
    private String shaChecksum = null;

    public void computeChecksum() throws JsonProcessingException {
        StringBuilder md5 = new StringBuilder();
        StringBuilder sha = new StringBuilder();
        checksums.entrySet().stream()
                .filter(entry -> entry.getValue() != null) // Filtrer les entrées non nulles
                .forEach(entry -> {
                    Pair<String, String> pair = entry.getValue(); // Récupère la paire MD5, SHA

                    // Si MD5 est non nul, on l'ajoute à la concaténation
                    if (pair.getLeft() != null) {
                        md5.append(pair.getLeft());
                    }

                    // Si SHA est non nul, on l'ajoute à la concaténation
                    if (pair.getRight() != null) {
                        sha.append(pair.getRight());
                    }
                });

        // Affichage des résultats
        md5Checksum = org.apache.commons.codec.digest.DigestUtils.md5Hex(md5.toString());
        shaChecksum = org.apache.commons.codec.digest.DigestUtils.sha1Hex(sha.toString());
        System.out.println("MD5 Concatenation: " + md5Checksum);
        System.out.println("SHA Concatenation: " + shaChecksum);
        System.out.println(this.stringify());
    }

    private void addChecksum(String key, String strValue) {
        if (this.useChecksum) this.checksums.put(key, calcChecksums(strValue));
    }

    private boolean ifNewKey(String key) {
        return !this.values.containsKey(key) && !this.datatypes.containsKey(key) && !this.checksums.containsKey(key);
    }
    public void putStr(String key, String value) {
        if (ifNewKey(key)) {
            this.values.put(key, value);
            this.datatypes.put(key, DataTypes.VARCHAR);
            this.addChecksum(key, value);
        }
    }
    public void putInt(String key, Integer value) {
        if (ifNewKey(key)) {
            this.values.put(key, value);
            this.datatypes.put(key, DataTypes.INTEGER);
            this.addChecksum(key, Integer.toString(value));
        }
    }
    public void putDouble(String key, Double value) {
        if (ifNewKey(key)) {
            this.values.put(key, value);
            this.datatypes.put(key, DataTypes.DOUBLE);
            this.addChecksum(key, Double.toString(value));
        }
    }
    public void putFloat(String key, Float value) {
        if (ifNewKey(key)) {
            this.values.put(key, value);
            this.datatypes.put(key, DataTypes.FLOAT);
            this.addChecksum(key, Float.toString(value));
        }
    }
    public void putDate(String key, Date value) {
        if (ifNewKey(key)) {
            this.values.put(key, value);
            this.datatypes.put(key, DataTypes.DATE);
            this.addChecksum(key, dateToString(value));
        }
    }
    public void putDateTime(String key, Timestamp value) {
        if (ifNewKey(key)) {
            this.values.put(key, value);
            this.datatypes.put(key, DataTypes.TIMESTAMP);
            this.addChecksum(key, dateToString(value));
        }
    }
    public void putBoolean(String key, Boolean value) {
        if (ifNewKey(key)) {
            this.values.put(key, value);
            this.datatypes.put(key, DataTypes.BOOLEAN);
            this.addChecksum(key, Boolean.toString(value));
        }
    }
    public void putBlob(String key, byte[] value) {
        if (ifNewKey(key)) {
            this.values.put(key, value);
            this.datatypes.put(key, DataTypes.BLOB);
            this.addChecksum(key, Arrays.toString(value));
        }
    }

    private Map<String, String> formatValues() {
        return this.values.entrySet().stream()
                .filter(entry -> entry.getValue().toString() != null)
                .collect(Collectors.toMap(
                        Map.Entry::getKey,
                        entry -> entry.getValue().toString()
                ));
    }

    public String stringify() throws JsonProcessingException {
        ObjectMapper objectMapper = new ObjectMapper();
        if (stringOnly)
            return objectMapper.writeValueAsString(this.formatValues());
        else
            return objectMapper.writeValueAsString(this.values);
    }
}