package data.sparadrap;

public enum DataTypes {
    VARCHAR,
    INTEGER,
    DOUBLE,
    FLOAT,
    DATE,
    TIMESTAMP,
    BOOLEAN,
    BLOB
}