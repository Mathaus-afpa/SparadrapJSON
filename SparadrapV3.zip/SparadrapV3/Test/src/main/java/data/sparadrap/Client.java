package data.sparadrap;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;

import javax.swing.*;
import java.awt.*;
import java.sql.Date;

/**
 * [Client] - class
 * @author Mathaus
 */
public class Client {
	@JsonProperty("IDCLIENT")
	private Integer idClient;
	@JsonProperty("IDPERSONNE")
	private Integer idPersonne;
	@JsonProperty("IDMUTUELLE")
	private Integer idMutuelle;

	public Integer getIdClient() {
		return idClient;
	}

	public void setIdClient(Integer idClient) {
		this.idClient = idClient;
	}

	public Integer getIdPersonne() {
		return idPersonne;
	}

	public void setIdPersonne(Integer idPersonne) {
		this.idPersonne = idPersonne;
	}

	public Integer getIdMutuelle() {
		return idMutuelle;
	}

	public void setIdMutuelle(Integer idMutuelle) {
		this.idMutuelle = idMutuelle;
	}

	public Date getDateDeNaissance() {
		return dateDeNaissance;
	}

	public void setDateDeNaissance(Date dateDeNaissance) {
		this.dateDeNaissance = dateDeNaissance;
	}


	@JsonProperty("DATEDENAISSANCE")
	@JsonFormat(pattern="dd-MM-yyyy")
	private Date dateDeNaissance;

	public String getNumeroSecuriteSociale() {
		return numeroSecuriteSociale;
	}

	public void setNumeroSecuriteSociale(String numeroSecuriteSociale) {
		this.numeroSecuriteSociale = numeroSecuriteSociale;
	}

	@JsonProperty("NUMEROSECURITESOCIALE")
	private String numeroSecuriteSociale;
}