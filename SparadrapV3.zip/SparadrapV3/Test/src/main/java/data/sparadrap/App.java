package data.sparadrap;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import data.source.ORM;

import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Map;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args ) throws JsonProcessingException {
        ORM.collectTable("client");
        ORM.collectTable("medecin");
        ORM.collectTable("entite");
        for (Map.Entry<String, List<UniversalJSON>> entry : ORM.datasets.entrySet()) {
            String tableName = entry.getKey(); // La clé est le nom de la table
            List<UniversalJSON> jsonList = entry.getValue(); // La valeur est la liste de UniversalJSON

            // Afficher le nom de la table
            System.out.println("Table: " + tableName);

            // Parcourir chaque élément de la liste et afficher son contenu
            for (UniversalJSON universalJSON : jsonList) {
                universalJSON.computeChecksum();
                // Supposons que UniversalJSON a une méthode pour l'affichage
                //System.out.println(universalJSON.stringify());  // Afficher l'objet ou utilisez une méthode personnalisée
            }

            // Ajouter une ligne vide pour séparer les différentes tables
            System.out.println();
        }

        String json;
        try {
            json = SparadrapDAO.call();
            System.out.println(json);
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }

         //"{ \"dateDeNaissance\": \"1992-08-22\", \"numeroSecuriteSociale\": 2047483647, \"idClient\": 2, \"idPersonne\": 2 }";
        ObjectMapper objectMapper = new ObjectMapper();

        // Configurer Jackson pour traiter les dates au format spécifique
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        objectMapper.setDateFormat(new SimpleDateFormat("dd-MM-yyyy"));

        try {
            // Désérialiser le JSON en objet Client
            Client client = objectMapper.readValue(json, Client.class);

            // Afficher le client pour vérification
            System.out.println("Client ID: " + client.getIdClient());
            System.out.println("Date de naissance: " + client.getDateDeNaissance());
            System.out.println("Numéro Sécurité Sociale: " + client.getNumeroSecuriteSociale());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}