package data.source;
import data.sparadrap.UniversalJSON;


import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * [ORM] - class
 * @author Mathaus
 */
public class ORM {
	//<editor-fold defaultstate="expanded" desc="STATIC">
	//START________________________________________________[static]___________________________________________________//
	//<editor-fold defaultstate="expanded" desc="PUBLIC">
	public static final String SELECT = "SELECT * FROM ";
	//<editor-fold defaultstate="expanded" desc="Proprietes PUBLIC">
	public static Map<String, List<UniversalJSON>> datasets = new HashMap<>();

    //</editor-fold>
	//<editor-fold defaultstate="expanded" desc="Fonctions PUBLIC">
	public static void collectTable(String table) {
		try {
			// Charger le driver MySQL
			Class.forName("com.mysql.cj.jdbc.Driver");
			// Etablir la connexion
			Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
			// Si la connexion est réussie
			if (connection != null) {
				Statement statement = connection.createStatement();
				StringBuilder sql = new StringBuilder();
				sql.append(SELECT).append(table);
				ResultSet resultSet = statement.executeQuery(sql.toString());
				ResultSetMetaData metaData = resultSet.getMetaData();
				int columnCount = metaData.getColumnCount();

				List<UniversalJSON> rows = new ArrayList<>();
				while (resultSet.next()) {
					UniversalJSON universalJSON = new UniversalJSON();
					for (int i = 1; i <= columnCount; i++) {
						String columnName = metaData.getColumnName(i);
						String columnTypeName = metaData.getColumnTypeName(i);
						Object value = resultSet.getObject(i);
						if (value != null) {
							switch (columnTypeName) {
								case "INT":
								case "INTEGER":
									universalJSON.putInt(columnName, (Integer) value);
									break;
								case "VARCHAR":
								case "CHAR":
								case "TEXT":
								case "LONGTEXT":
								case "MEDIUMTEXT":
									universalJSON.putStr(columnName, (String) value);
									break;
								case "FLOAT":
									universalJSON.putFloat(columnName, (Float) value);
									break;
								case "DOUBLE":
								case "REAL":
									universalJSON.putDouble(columnName, (Double) value);
									break;
								case "DECIMAL":
								case "NUMERIC":
								case "TINYINT":
									// Gestion des petits entiers
									universalJSON.putInt(columnName, (Integer) value);
									break;
								case "SMALLINT":
									// Gestion des petits entiers
									universalJSON.putInt(columnName, (Integer) value);
									break;
								case "BIGINT":
									break;

								case "DATE":
									universalJSON.putDate(columnName, (Date) value);
									break;
								case "DATETIME":
								case "TIMESTAMP":
									universalJSON.putDateTime(columnName, (Timestamp) value);
									break;

								case "TIME":
									break;

								case "BIT":
								case "BOOL":
									universalJSON.putBoolean(columnName, (Boolean) value);
									break;

								case "BLOB":
								case "MEDIUMBLOB":
								case "LONGBLOB":
									// Gestion des objets binaires (BLOBs)
									universalJSON.putBlob(columnName, (byte[]) value);
									break;

								case "JSON":
									// Gestion des objets JSON (si votre base supporte JSON)
									//universalJSON.putJson(columnName, (String) value);
									break;

								default:
									// Pour les autres types, les valeurs sont retournées en chaîne de caractères par défaut
									universalJSON.putStr(columnName, value != null ? value.toString() : null);
									break;
							}

						}
					}
					rows.add(universalJSON);
				}
				datasets.put(table, rows);
				resultSet.close();
			}
			// Fermer la connexion
			connection.close();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	private static final String URL = "jdbc:mysql://localhost:3306/sparadrap";
	private static final String USER = "root";
	private static final String PASSWORD = "root";
    //</editor-fold>
	//</editor-fold>
	//<editor-fold defaultstate="expanded" desc="PRIVATE">
    //<editor-fold defaultstate="expanded" desc="Proprietes PRIVATE">
    //</editor-fold>
    //<editor-fold defaultstate="expanded" desc="Fonctions PRIVATE">
    //</editor-fold>
	//</editor-fold>
    //END//////////////////////////////////////////////////[static]/////////////////////////////////////////////////////
	//</editor-fold>
	//<editor-fold defaultstate="expanded" desc="INSTANCE">
    //START_______________________________________________[instance]__________________________________________________//
    //<editor-fold defaultstate="expanded" desc="SINGLETON">
    //</editor-fold>
    //<editor-fold defaultstate="expanded" desc="CONSTRUCTEURS">
	private ORM() {}
    //</editor-fold>
	//<editor-fold defaultstate="expanded" desc="PUBLIC">
    //<editor-fold defaultstate="expanded" desc="Attributs PUBLIC">
    //</editor-fold>
	//<editor-fold defaultstate="expanded" desc="Methodes PUBLIC">
    //</editor-fold>
	//</editor-fold>
	//<editor-fold defaultstate="expanded" desc="PRIVATE">
    //<editor-fold defaultstate="expanded" desc="Attributs PRIVATE">
    //</editor-fold>
    //<editor-fold defaultstate="expanded" desc="Methodes PRIVATE">
    //</editor-fold>
	//</editor-fold>
	//<editor-fold defaultstate="expanded" desc="ENCAPSULATION">
    //<editor-fold defaultstate="expanded" desc="Getters">
    //</editor-fold>
    //<editor-fold defaultstate="expanded" desc="Setters">
    //</editor-fold>
	//</editor-fold>
    //END/////////////////////////////////////////////////[instance]////////////////////////////////////////////////////
	//</editor-fold>
	//<editor-fold defaultstate="expanded" desc="OVERRIDE">
	//START_______________________________________________[override]__________________________________________________//
	//END/////////////////////////////////////////////////[override]////////////////////////////////////////////////////
	//</editor-fold>
}